CREATE TABLE "ngrinder_delete_test"(
"test_id" integer,
"test_number" integer
);

CREATE TABLE "ngrinder_insert_test"(
"test_id" integer,
"test_number" integer
);

CREATE TABLE "ngrinder_select_test"(
"test_id" integer,
"test_number" integer
);

CREATE TABLE "ngrinder_update_test"(
"test_id" integer,
"test_number" integer
);

